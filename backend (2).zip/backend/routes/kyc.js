// backend/routes/kyc.js
// KYC document routes — all file I/O via Cloudflare R2 presigned URLs.
'use strict';

const express = require('express');
const router = express.Router();
const authenticateToken = require('../middleware/authenticateToken');
const ctrl = require('../controllers/kycController');

const isAdminOrHr = (req, res, next) => {
    if (!['Admin', 'HR'].includes(req.user.role)) {
        return res.status(403).json({ error: 'Access forbidden: requires Admin or HR role.' });
    }
    next();
};

// ─── Public catalogue ─────────────────────────────────────────────────────────
router.get('/types', authenticateToken, ctrl.getDocumentTypes);

// ─── Employee endpoints ───────────────────────────────────────────────────────
// Get my current KYC document statuses
router.get('/my-documents', authenticateToken, ctrl.getMyDocuments);

// Step 1 — request a presigned PUT URL
router.post('/request-upload', authenticateToken, ctrl.requestUpload);

// Step 2 — confirm the upload completed and create the metadata record
router.post('/confirm-upload', authenticateToken, ctrl.confirmUpload);

// View / download (presigned GET URL) — employees see their own; admins see all
router.get('/view/:docId', authenticateToken, ctrl.viewDocument);

// ─── Admin / HR endpoints ─────────────────────────────────────────────────────
// All KYC records for a specific employee
router.get('/admin/employee/:employeeId', authenticateToken, isAdminOrHr, ctrl.getEmployeeDocuments);

// Paginated list across all employees
router.get('/admin/all', authenticateToken, isAdminOrHr, ctrl.getAllDocuments);

// Verify a document
router.post('/admin/verify/:docId', authenticateToken, isAdminOrHr, ctrl.verifyDocument);

// Reject a document (requires a reason in the body)
router.post('/admin/reject/:docId', authenticateToken, isAdminOrHr, ctrl.rejectDocument);

module.exports = router;
