// backend/routes/publicForm.js
const express = require('express');
const router = express.Router();
const rateLimit = require('express-rate-limit');
const publicFormController = require('../controllers/publicFormController');
const kycController = require('../controllers/kycController');
const EmployeePublicToken = require('../models/EmployeePublicToken');
const User = require('../models/User');
const {
  profileSubmissionRules,
  validate,
  sanitizeProfileData,
  rateLimitConfig,
  kycUploadLimiterConfig
} = require('../middleware/publicFormValidation');

// Strict limiter for form token validation and submission (5 req / 15 min)
const publicLimiter = rateLimit(rateLimitConfig);

// Relaxed limiter for KYC document upload steps (50 req / 15 min)
// Employees upload multiple documents in one session, so the strict
// submission limit would incorrectly block legitimate upload requests.
const kycUploadLimiter = rateLimit(kycUploadLimiterConfig);

// ─── Middleware: validate public-form token → attach req.employeeId (MongoDB ObjectId) ──
// Reuses exactly the same validation logic as publicFormService.validateToken,
// but does NOT mark the token as used — uploads happen before final submission.
const validatePublicFormToken = async (req, res, next) => {
  try {
    const token = (req.body && req.body.token) || req.query.token;
    if (!token) {
      return res.status(401).json({ error: 'Token is required.' });
    }

    const tokenDoc = await EmployeePublicToken.findOne({ token });
    if (!tokenDoc) {
      return res.status(401).json({ error: 'Invalid token.' });
    }
    if (new Date() > tokenDoc.expiresAt) {
      return res.status(401).json({ error: 'Token expired.', expired: true });
    }
    if (tokenDoc.isUsed && !tokenDoc.allowMultipleSubmissions) {
      return res.status(401).json({ error: 'Token already used.', alreadyUsed: true });
    }

    // Resolve employee — tokenDoc.employeeId stores the employeeCode string
    const employee = await User.findOne({ employeeCode: tokenDoc.employeeId }).select('_id').lean();
    if (!employee) {
      return res.status(401).json({ error: 'Employee not found.' });
    }

    // Attach the MongoDB ObjectId so KYC controller can use it directly
    req.employeeId = employee._id.toString();
    next();
  } catch (err) {
    console.error('[PublicFormToken] Middleware error:', err);
    res.status(500).json({ error: 'Token validation failed.' });
  }
};

// ─── PUBLIC ROUTES (NO AUTH REQUIRED) ──────────────────────────────────────

/**
 * Validate token and get employee data
 * GET /api/public/validate?token=xxx
 */
router.get('/validate', publicLimiter, publicFormController.validateToken);

/**
 * Submit profile data
 * POST /api/public/submit
 */
router.post(
  '/submit',
  publicLimiter,
  sanitizeProfileData,
  profileSubmissionRules,
  validate,
  publicFormController.submitProfile
);

// ─── KYC UPLOAD ROUTES — token-authenticated (no JWT required) ─────────────

/**
 * Get current KYC document statuses for the employee
 * GET /api/public/kyc/my-documents?token=xxx
 */
router.get('/kyc/my-documents', kycUploadLimiter, validatePublicFormToken, kycController.publicGetMyDocuments);

/**
 * Step 1 — request a presigned PUT URL
 * POST /api/public/kyc/request-upload
 * Body: { token, documentType, originalFileName, mimeType, fileSize }
 */
router.post('/kyc/request-upload', kycUploadLimiter, validatePublicFormToken, kycController.publicRequestUpload);

/**
 * Step 2 — confirm the upload and create the metadata record
 * POST /api/public/kyc/confirm-upload
 * Body: { token, documentType, storageKey, originalFileName, mimeType, fileSize }
 */
router.post('/kyc/confirm-upload', kycUploadLimiter, validatePublicFormToken, kycController.publicConfirmUpload);

module.exports = router;
