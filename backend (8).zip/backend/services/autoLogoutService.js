// backend/services/autoLogoutService.js
/**
 * Intelligent Auto Logout Service
 * 
 * This service enforces automatic logout for employees who forget to log out.
 * It runs as a backend cron job and does NOT depend on frontend being open.
 * 
 * Rules:
 * 1. Expected logout = shiftStart + shiftDuration + unpaidBreak + approvedOvertime (if any)
 * 2. Allow up to 1 hour overtime without auto logout
 * 3. Auto logout triggers after: expected logout + 1 hour (overtime) + 90 minutes (buffer)
 * 4. Auto logout = expected logout + 2.5 hours
 */

const mongoose = require('mongoose');
const AttendanceLog = require('../models/AttendanceLog');
const AttendanceSession = require('../models/AttendanceSession');
const BreakLog = require('../models/BreakLog');
const User = require('../models/User');
const { getUserDailyStatus } = require('./dailyStatusService');

// Note: We cannot import computeCalculatedLogoutTime directly as it requires sessions/breaks arrays
// Instead, we use getUserDailyStatus which internally computes the logout time correctly

// Constants
const OVERTIME_ALLOWANCE_MINUTES = 60; // 1 hour overtime allowed
const AUTO_LOGOUT_BUFFER_MINUTES = 90; // 90 minutes buffer after expected logout + overtime
const TOTAL_AUTO_LOGOUT_DELAY_MINUTES = OVERTIME_ALLOWANCE_MINUTES + AUTO_LOGOUT_BUFFER_MINUTES; // 2.5 hours total

/**
 * Calculate expected logout time for an employee based on their shift and breaks
 * Uses getUserDailyStatus which contains the authoritative logout calculation logic
 */
const calculateExpectedLogoutTime = async (userId, attendanceDate) => {
    try {
        // Get daily status which includes the calculated logout time
        // This uses the same logic as the frontend and ensures consistency
        const dailyStatus = await getUserDailyStatus(
            userId,
            attendanceDate,
            { includeSessions: true, includeBreaks: true, includeAutoBreak: true }
        );

        if (dailyStatus && dailyStatus.calculatedLogoutTime) {
            const logoutTime = new Date(dailyStatus.calculatedLogoutTime);
            // Validate that the logout time is a valid date
            if (isNaN(logoutTime.getTime())) {
                console.error(`[autoLogoutService] Invalid logout time calculated for user ${userId}, date ${attendanceDate}`);
                return null;
            }
            return logoutTime;
        }

        // Fallback: If calculatedLogoutTime is not available, try to calculate from shift
        // This handles edge cases where getUserDailyStatus might not return a calculated time
        if (dailyStatus && dailyStatus.shift && dailyStatus.attendanceLog) {
            const user = await User.findById(userId).populate('shiftGroup').lean();
            if (user && user.shiftGroup) {
                const shift = user.shiftGroup;
                const attendanceLog = await AttendanceLog.findOne({ user: userId, attendanceDate }).lean();
                if (attendanceLog && attendanceLog.clockInTime) {
                    // Basic calculation: clockInTime + shift duration (9 hours)
                    const clockInTime = new Date(attendanceLog.clockInTime);
                    const shiftDurationMinutes = shift.durationHours ? shift.durationHours * 60 : 540; // Default 9 hours
                    const expectedLogout = new Date(clockInTime.getTime() + shiftDurationMinutes * 60 * 1000);
                    console.log(`[autoLogoutService] ⚠️ Using fallback calculation for user ${userId}: ${expectedLogout.toISOString()}`);
                    return expectedLogout;
                }
            }
        }

        return null;
    } catch (error) {
        console.error('[autoLogoutService] Error calculating expected logout time:', error);
        console.error('[autoLogoutService]   Error stack:', error.stack);
        return null;
    }
};

/**
 * Calculate auto logout threshold time
 * Auto logout time = expected logout + overtime allowance + buffer
 */
const calculateAutoLogoutThreshold = (expectedLogoutTime) => {
    if (!expectedLogoutTime) return null;
    
    const autoLogoutTime = new Date(expectedLogoutTime);
    autoLogoutTime.setMinutes(autoLogoutTime.getMinutes() + TOTAL_AUTO_LOGOUT_DELAY_MINUTES);
    return autoLogoutTime;
};

/**
 * Perform auto logout for a specific attendance session
 */
const performAutoLogout = async (attendanceLog, activeSession, user) => {
    try {
        const now = new Date();
        
        // CRITICAL: Check if already logged out (prevent duplicate auto-logouts)
        const currentLog = await AttendanceLog.findById(attendanceLog._id).lean();
        if (currentLog && currentLog.clockOutTime) {
            console.log(`[autoLogoutService] ⚠️ User ${user.email} already has clockOutTime set, skipping duplicate auto-logout`);
            return false;
        }

        // CRITICAL: Check if session is still active (prevent duplicate auto-logouts)
        const currentSession = await AttendanceSession.findById(activeSession._id).lean();
        if (currentSession && currentSession.endTime) {
            console.log(`[autoLogoutService] ⚠️ Session ${activeSession._id} already has endTime set, skipping duplicate auto-logout`);
            // Still update attendance log if clockOutTime is null
            if (!currentLog.clockOutTime) {
                await AttendanceLog.findByIdAndUpdate(attendanceLog._id, {
                    $set: {
                        clockOutTime: currentSession.endTime,
                        logoutType: 'AUTO',
                        autoLogoutReason: `Auto-logged out after exceeding expected logout time + ${TOTAL_AUTO_LOGOUT_DELAY_MINUTES} minutes buffer`
                    }
                });
            }
            return false;
        }

        // For past dates, use the expected logout time + buffer as the logout time
        // For today, use current time
        const attendanceDate = new Date(attendanceLog.attendanceDate + 'T00:00:00');
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        attendanceDate.setHours(0, 0, 0, 0);
        const isPastDate = attendanceDate < today;

        let logoutTime = now;
        if (isPastDate) {
            // For past dates, calculate the auto-logout threshold time
            const expectedLogoutTime = await calculateExpectedLogoutTime(user._id, attendanceLog.attendanceDate);
            if (expectedLogoutTime) {
                const threshold = calculateAutoLogoutThreshold(expectedLogoutTime);
                // Use threshold time, but don't go beyond the session start time + reasonable max (e.g., 24 hours)
                const maxSessionDuration = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
                const sessionStartTime = new Date(activeSession.startTime);
                const maxLogoutTime = new Date(sessionStartTime.getTime() + maxSessionDuration);
                logoutTime = threshold < maxLogoutTime ? threshold : maxLogoutTime;
                console.log(`[autoLogoutService] 📅 Using calculated logout time for past date: ${logoutTime.toISOString()}`);
            }
        }
        
        // End the active session
        await AttendanceSession.findByIdAndUpdate(activeSession._id, {
            $set: {
                endTime: logoutTime,
                logoutType: 'AUTO',
                autoLogoutReason: `Auto-logged out after exceeding expected logout time + ${TOTAL_AUTO_LOGOUT_DELAY_MINUTES} minutes buffer`
            }
        });

        // Recalculate total working hours
        const allSessions = await AttendanceSession.find({ attendanceLog: attendanceLog._id }).sort({ startTime: 1 });
        const breaks = await BreakLog.find({ attendanceLog: attendanceLog._id });

        let totalWorkingMinutes = 0;
        let totalBreakMinutes = 0;

        // Calculate total session time
        allSessions.forEach(session => {
            if (session.endTime) {
                const sessionMinutes = (new Date(session.endTime) - new Date(session.startTime)) / (1000 * 60);
                totalWorkingMinutes += sessionMinutes;
            }
        });

        // Calculate total break time
        breaks.forEach(breakLog => {
            if (breakLog.endTime) {
                const breakMinutes = (new Date(breakLog.endTime) - new Date(breakLog.startTime)) / (1000 * 60);
                totalBreakMinutes += breakMinutes;
            }
        });

        // Net working hours (excluding breaks)
        const netWorkingMinutes = Math.max(0, totalWorkingMinutes - totalBreakMinutes);
        const totalWorkingHours = netWorkingMinutes / 60;

        // Update attendance log with clock-out time and auto-logout info
        await AttendanceLog.findByIdAndUpdate(attendanceLog._id, {
            $set: {
                clockOutTime: logoutTime,
                totalWorkingHours: totalWorkingHours,
                logoutType: 'AUTO',
                autoLogoutReason: `Auto-logged out after exceeding expected logout time + ${TOTAL_AUTO_LOGOUT_DELAY_MINUTES} minutes buffer`
            }
        });

        console.log(`[autoLogoutService] ✅ Auto-logged out user ${user.fullName} (${user.email}) at ${logoutTime.toISOString()}`);
        console.log(`[autoLogoutService]   Total working hours: ${totalWorkingHours.toFixed(2)}h`);
        console.log(`[autoLogoutService]   Attendance date: ${attendanceLog.attendanceDate}`);

        return true;
    } catch (error) {
        console.error(`[autoLogoutService] ❌ Error performing auto-logout for user ${user?.email}:`, error);
        console.error(`[autoLogoutService]   Error stack:`, error.stack);
        return false;
    }
};

/**
 * Check and auto-logout employees who have exceeded their logout threshold
 * This is the main function called by the cron job
 */
const checkAndAutoLogout = async () => {
    const checkStartTime = new Date();
    console.log(`[autoLogoutService] 🔍 Running auto-logout check at ${checkStartTime.toISOString()}`);

    // Check if database is connected
    if (mongoose.connection.readyState !== 1) {
        console.log('[autoLogoutService] ⚠️ Database not connected, skipping auto-logout check');
        return;
    }

    try {
        const now = new Date();

        // Find all attendance logs with active sessions (no clockOutTime and active session)
        // CRITICAL: This includes logs from previous days (yesterday, etc.) that weren't logged out
        const activeAttendanceLogs = await AttendanceLog.find({
            clockOutTime: null // Not yet logged out
        }).populate('user').lean();

        if (!activeAttendanceLogs || activeAttendanceLogs.length === 0) {
            console.log('[autoLogoutService] ℹ️ No active attendance sessions found');
            return;
        }

        console.log(`[autoLogoutService] 📊 Found ${activeAttendanceLogs.length} active attendance log(s) to check`);

        let autoLogoutCount = 0;
        let skippedCount = 0;
        let processedCount = 0;

        for (const attendanceLog of activeAttendanceLogs) {
            try {
                processedCount++;
                
                // Skip if user is not found or inactive
                if (!attendanceLog.user || !attendanceLog.user.isActive) {
                    console.log(`[autoLogoutService] ⏭️ Skipping inactive user: ${attendanceLog.user?.email || 'unknown'}`);
                    skippedCount++;
                    continue;
                }

                // Get active session for this attendance log
                const activeSession = await AttendanceSession.findOne({
                    attendanceLog: attendanceLog._id,
                    endTime: null // Still active
                }).lean();

                if (!activeSession) {
                    // No active session, but clockOutTime is null - data inconsistency
                    // This can happen if a session was manually closed but clockOutTime wasn't updated
                    // Try to fix this by setting clockOutTime to the last session's endTime
                    const lastSession = await AttendanceSession.findOne({
                        attendanceLog: attendanceLog._id
                    }).sort({ endTime: -1 }).lean();
                    
                    if (lastSession && lastSession.endTime) {
                        console.log(`[autoLogoutService] 🔧 Fixing data inconsistency for ${attendanceLog.user?.email || 'unknown'}: Setting clockOutTime to last session endTime`);
                        await AttendanceLog.findByIdAndUpdate(attendanceLog._id, {
                            $set: { clockOutTime: lastSession.endTime }
                        });
                    }
                    skippedCount++;
                    continue;
                }

                // Populate user with shift group
                const user = await User.findById(attendanceLog.user._id || attendanceLog.user).populate('shiftGroup');
                if (!user || !user.shiftGroup) {
                    console.log(`[autoLogoutService] ⚠️ User ${attendanceLog.user?.email || 'unknown'} has no shift assigned, skipping`);
                    skippedCount++;
                    continue;
                }

                // Log attendance date for debugging
                const attendanceDateObj = new Date(attendanceLog.attendanceDate + 'T00:00:00');
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                attendanceDateObj.setHours(0, 0, 0, 0);
                const daysDiff = Math.floor((today - attendanceDateObj) / (1000 * 60 * 60 * 24));
                
                if (daysDiff > 0) {
                    console.log(`[autoLogoutService] 📅 Processing ${daysDiff} day(s) old attendance log for ${user.email} (date: ${attendanceLog.attendanceDate})`);
                    
                    // Warn if log is very old (more than 7 days) - might indicate data inconsistency
                    if (daysDiff > 7) {
                        console.log(`[autoLogoutService] ⚠️ WARNING: Very old attendance log (${daysDiff} days) for ${user.email}. This might indicate a data inconsistency.`);
                    }
                }

                // Calculate expected logout time using the daily status service
                // This ensures we use the same calculation logic as everywhere else
                const expectedLogoutTime = await calculateExpectedLogoutTime(
                    user._id,
                    attendanceLog.attendanceDate
                );

                if (!expectedLogoutTime) {
                    console.log(`[autoLogoutService] ⚠️ Could not calculate expected logout time for user ${user.email} (date: ${attendanceLog.attendanceDate}), skipping`);
                    skippedCount++;
                    continue;
                }

                // Calculate auto logout threshold
                const autoLogoutThreshold = calculateAutoLogoutThreshold(expectedLogoutTime);

                if (!autoLogoutThreshold) {
                    console.log(`[autoLogoutService] ⚠️ Could not calculate auto-logout threshold for user ${user.email}, skipping`);
                    skippedCount++;
                    continue;
                }

                // CRITICAL: Handle overnight shifts
                // For overnight shifts, the logout time might be on the next day
                // Check if the expected logout time is actually on the next day compared to attendance date
                const expectedLogoutDate = new Date(expectedLogoutTime);
                expectedLogoutDate.setHours(0, 0, 0, 0);
                // Reuse attendanceDateObj that was already declared above
                const isOvernightShift = expectedLogoutDate > attendanceDateObj;
                
                if (isOvernightShift) {
                    console.log(`[autoLogoutService] 🌙 Detected overnight shift for ${user.email} (logout on next day)`);
                }

                // CRITICAL: For past dates (yesterday or older), auto-logout immediately if threshold has passed
                // For today's date, check if threshold has been exceeded
                // For overnight shifts, also check if we're past the threshold
                const shouldAutoLogout = now >= autoLogoutThreshold;

                if (shouldAutoLogout) {
                    console.log(`[autoLogoutService] ⏰ User ${user.email} exceeded auto-logout threshold`);
                    console.log(`[autoLogoutService]   Attendance Date: ${attendanceLog.attendanceDate}`);
                    console.log(`[autoLogoutService]   Expected logout: ${expectedLogoutTime.toISOString()}`);
                    console.log(`[autoLogoutService]   Auto-logout threshold: ${autoLogoutThreshold.toISOString()}`);
                    console.log(`[autoLogoutService]   Current time: ${now.toISOString()}`);
                    console.log(`[autoLogoutService]   Time exceeded by: ${Math.round((now - autoLogoutThreshold) / (1000 * 60))} minutes`);
                    
                    // Perform auto logout
                    const success = await performAutoLogout(attendanceLog, activeSession, user);
                    if (success) {
                        autoLogoutCount++;
                        console.log(`[autoLogoutService] ✅ Successfully auto-logged out ${user.email}`);
                    } else {
                        console.log(`[autoLogoutService] ❌ Failed to auto-logout ${user.email}`);
                    }
                } else {
                    // Not yet time for auto-logout
                    const minutesUntilAutoLogout = Math.round((autoLogoutThreshold - now) / (1000 * 60));
                    if (minutesUntilAutoLogout <= 30 && minutesUntilAutoLogout > 0) {
                        // Log warning if within 30 minutes of auto-logout
                        console.log(`[autoLogoutService] ⚠️ User ${user.email} will be auto-logged out in ~${minutesUntilAutoLogout} minutes`);
                    }
                }
            } catch (error) {
                console.error(`[autoLogoutService] ❌ Error processing attendance log ${attendanceLog._id}:`, error);
                console.error(`[autoLogoutService]   Error stack:`, error.stack);
                skippedCount++;
            }
        }

        const checkDuration = Math.round((new Date() - checkStartTime) / 1000);
        console.log(`[autoLogoutService] ✅ Auto-logout check completed in ${checkDuration}s`);
        console.log(`[autoLogoutService] 📊 Summary: Processed: ${processedCount}, Auto-logged out: ${autoLogoutCount}, Skipped: ${skippedCount}`);
    } catch (error) {
        console.error('[autoLogoutService] ❌ Fatal error in auto-logout check:', error);
        console.error('[autoLogoutService]   Error stack:', error.stack);
    }
};

module.exports = {
    checkAndAutoLogout,
    calculateExpectedLogoutTime,
    calculateAutoLogoutThreshold,
    performAutoLogout,
    OVERTIME_ALLOWANCE_MINUTES,
    AUTO_LOGOUT_BUFFER_MINUTES,
    TOTAL_AUTO_LOGOUT_DELAY_MINUTES
};

