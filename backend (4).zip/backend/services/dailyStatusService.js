// backend/services/dailyStatusService.js
const User = require('../models/User');
const AttendanceLog = require('../models/AttendanceLog');
const AttendanceSession = require('../models/AttendanceSession');
const BreakLog = require('../models/BreakLog');
const ExtraBreakRequest = require('../models/ExtraBreakRequest');
const Setting = require('../models/Setting');
const { 
    SHIFT_WORKING_MINUTES, 
    PAID_BREAK_ALLOWANCE_MINUTES,
    calculateRequiredLogoutTime 
} = require('../config/shiftPolicy');

const DEFAULT_OPTIONS = {
    includeSessions: true,
    includeBreaks: true,
    includeRequests: true,
    includeAutoBreak: true,
};

const getShiftDateTimeIST = (onDate, shiftTime) => {
    const [hours, minutes] = shiftTime.split(':').map(Number);
    const istDateFormatter = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Asia/Kolkata',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
    });
    const [{ value: year }, , { value: month }, , { value: day }] = istDateFormatter.formatToParts(onDate);
    const shiftDateTimeISO_IST = `${year}-${month}-${day}T${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:00.000+05:30`;
    return new Date(shiftDateTimeISO_IST);
};

/**
 * Recalculates late/half-day status based on current clockInTime.
 * This is the SINGLE SOURCE OF TRUTH for derived attendance status.
 * 
 * @param {Date} clockInTime - The actual clock-in time
 * @param {Object} shift - The user's shift object with startTime
 * @param {number} gracePeriodMinutes - Grace period in minutes (default: 30)
 * @returns {Object} { lateMinutes, isLate, isHalfDay, attendanceStatus }
 */
const recalculateLateStatus = async (clockInTime, shift, gracePeriodMinutes = null) => {
    if (!clockInTime || !shift || !shift.startTime) {
        return {
            lateMinutes: 0,
            isLate: false,
            isHalfDay: false,
            attendanceStatus: 'On-time'
        };
    }

    const clockIn = new Date(clockInTime);
    const shiftStartTime = getShiftDateTimeIST(clockIn, shift.startTime);
    const lateMinutes = Math.max(0, Math.floor((clockIn - shiftStartTime) / (1000 * 60)));

    // Get grace period from settings if not provided
    let GRACE_PERIOD_MINUTES = gracePeriodMinutes;
    if (GRACE_PERIOD_MINUTES === null || GRACE_PERIOD_MINUTES === undefined) {
        try {
            const graceSetting = await Setting.findOne({ key: 'lateGraceMinutes' });
            if (graceSetting) {
                // FIX: Explicitly convert to integer to ensure type consistency
                const graceValue = parseInt(Number(graceSetting.value), 10);
                if (!isNaN(graceValue) && graceValue >= 0) {
                    GRACE_PERIOD_MINUTES = graceValue;
                } else {
                    console.warn(`[Grace Period] Invalid value in database: ${graceSetting.value}, using default 30`);
                    GRACE_PERIOD_MINUTES = 30; // Default
                }
            } else {
                GRACE_PERIOD_MINUTES = 30; // Default
            }
        } catch (err) {
            console.error('Failed to fetch late grace setting, falling back to 30 minutes', err);
            GRACE_PERIOD_MINUTES = 30;
        }
    }

    // Consistent rules:
    // - If lateMinutes <= GRACE_PERIOD_MINUTES -> On-time (within grace period)
    // - If lateMinutes > GRACE_PERIOD_MINUTES -> Half-day AND Late (for tracking/notifications)
    let isLate = false;
    let isHalfDay = false;
    let attendanceStatus = 'On-time';

    if (lateMinutes <= GRACE_PERIOD_MINUTES) {
        isLate = false;
        isHalfDay = false;
        attendanceStatus = 'On-time';
    } else if (lateMinutes > GRACE_PERIOD_MINUTES) {
        isHalfDay = true;
        isLate = true; // FIX: Set isLate=true for tracking and notifications
        attendanceStatus = 'Half-day';
    }

    return {
        lateMinutes,
        isLate,
        isHalfDay,
        attendanceStatus
    };
};

const buildBaseResponse = (options) => ({
    status: 'Not Clocked In',
    hasLog: false, // CRITICAL: Explicitly set to false to prevent stale UI state
    sessions: options.includeSessions ? [] : undefined,
    breaks: options.includeBreaks ? [] : undefined,
    shift: null,
    attendanceLog: null, // CRITICAL: Must be null when no log exists
    calculatedLogoutTime: null,
    pendingExtraBreakRequest: options.includeRequests ? null : undefined,
    approvedExtraBreak: options.includeRequests ? null : undefined,
    autoBreak: options.includeAutoBreak ? null : undefined,
    activeBreak: options.includeBreaks ? null : undefined,
});

/**
 * Maps attendance log data for response.
 * NOTE: isLate, isHalfDay, lateMinutes, and attendanceStatus are NOT included here
 * because they must be recalculated from clockInTime on every request.
 * See getUserDailyStatus for recalculation logic.
 */
const mapAttendanceLog = (attendanceLog) => ({
    penaltyMinutes: attendanceLog?.penaltyMinutes || 0,
    paidBreakMinutesTaken: attendanceLog?.paidBreakMinutesTaken || 0,
    unpaidBreakMinutesTaken: attendanceLog?.unpaidBreakMinutesTaken || 0,
    logoutType: attendanceLog?.logoutType || 'MANUAL',
    autoLogoutReason: attendanceLog?.autoLogoutReason || null,
    // CRITICAL: Do NOT include isLate, isHalfDay, lateMinutes, attendanceStatus here
    // These must be recalculated from clockInTime on every request
});

const mapAutoBreak = (autoBreakDoc) => autoBreakDoc ? ({
    id: autoBreakDoc._id,
    startTime: autoBreakDoc.startTime,
    type: autoBreakDoc.type,
    reason: autoBreakDoc.reason,
    duration: Math.floor((Date.now() - new Date(autoBreakDoc.startTime)) / (1000 * 60)),
}) : null;

const mapActiveBreak = (breakDoc) => breakDoc ? ({
    startTime: breakDoc.startTime,
    breakType: breakDoc.breakType,
    durationMinutes: Math.floor((Date.now() - new Date(breakDoc.startTime)) / (1000 * 60)),
}) : null;

/**
 * Calculate required logout time based on POLICY RULES (AUTHORITATIVE BACKEND CALCULATION)
 * 
 * POLICY:
 * - Shift working time: 8.5 hours (510 minutes)
 * - Allowed paid break: 30 minutes (included in shift)
 * - Required logout = clockInTime + working time + excess paid break + unpaid break
 * 
 * RULES:
 * 1. Base: clockInTime + 8.5 hours working time
 * 2. Paid break > 30 min → excess extends logout time
 * 3. All unpaid break time extends logout time
 * 
 * Returns both the logout time and breakdown metadata for UI display.
 */
const computeCalculatedLogoutTime = (sessions, breaks, attendanceLog, userShift, activeBreak = null) => {
    if (!sessions?.length || !userShift || !attendanceLog) {
        return null;
    }

    const firstClockInSession = sessions[0];
    const clockInTime = new Date(firstClockInSession.startTime);
    
    // Helper function to set time on a date (in IST)
    const setTime = (date, timeString) => {
        const [hours, minutes] = timeString.split(':').map(Number);
        return getShiftDateTimeIST(date, timeString);
    };

    // Helper function to add minutes to a date
    const addMinutes = (date, minutes) => {
        const newDate = new Date(date);
        newDate.setMinutes(newDate.getMinutes() + minutes);
        return newDate;
    };
    
    // ============================================
    // Calculate total break minutes from breaks array (AUTHORITATIVE SOURCE)
    // CRITICAL: Aggregate from breaks array instead of database field
    // This ensures we get the actual break durations, not capped/stale values
    // ============================================
    let paidBreakMinutesTaken = 0;
    let unpaidBreakMinutesTaken = 0;
    
    // Aggregate break minutes from breaks array (source of truth)
    if (breaks && Array.isArray(breaks)) {
        breaks.forEach(breakItem => {
            // Only count completed breaks (those with endTime)
            if (breakItem.endTime && breakItem.startTime) {
                const breakStart = new Date(breakItem.startTime);
                const breakEnd = new Date(breakItem.endTime);
                const durationMinutes = Math.round((breakEnd - breakStart) / (1000 * 60));
                
                // Handle both breakType and type for backward compatibility
                const breakType = (breakItem.breakType || breakItem.type || 'Unpaid').toString().trim();
                
                // Match breakType exactly (case-sensitive) as stored in database
                if (breakType === 'Paid') {
                    paidBreakMinutesTaken += durationMinutes;
                } else if (breakType === 'Unpaid' || breakType === 'Extra') {
                    unpaidBreakMinutesTaken += durationMinutes;
                }
            }
        });
    }
    
    // Fallback: If no breaks array provided or breaks array is empty, use database field (backward compatibility)
    // This ensures backward compatibility if breaks are not included in the query
    if ((!breaks || !Array.isArray(breaks) || breaks.length === 0) && paidBreakMinutesTaken === 0 && unpaidBreakMinutesTaken === 0) {
        paidBreakMinutesTaken = attendanceLog.paidBreakMinutesTaken || 0;
        unpaidBreakMinutesTaken = attendanceLog.unpaidBreakMinutesTaken || 0;
    }
    
    // Include active break duration if present (for real-time calculation)
    if (activeBreak && activeBreak.startTime) {
        const now = new Date();
        const activeBreakStart = new Date(activeBreak.startTime);
        const activeBreakDurationMinutes = Math.floor((now - activeBreakStart) / (1000 * 60));
        const activeBreakType = (activeBreak.breakType || activeBreak.type || '').toString().trim();
        
        if (activeBreakType === 'Paid') {
            paidBreakMinutesTaken += activeBreakDurationMinutes;
        } else if (activeBreakType === 'Unpaid' || activeBreakType === 'Extra') {
            unpaidBreakMinutesTaken += activeBreakDurationMinutes;
        }
    }
    
    // DEBUG: Log calculated values
    console.log('[computeCalculatedLogoutTime] Aggregated break values:', {
        paidBreakMinutesTaken,
        unpaidBreakMinutesTaken,
        breaksCount: breaks?.length || 0,
        clockInTime: clockInTime.toISOString()
    });
    
    // ============================================
    // USE AUTHORITATIVE POLICY CALCULATION
    // ============================================
    const result = calculateRequiredLogoutTime(
        clockInTime,
        paidBreakMinutesTaken,
        unpaidBreakMinutesTaken
    );
    
    if (!result) {
        console.log('[computeCalculatedLogoutTime] calculateRequiredLogoutTime returned null');
        return null;
    }
    
    // DEBUG: Log calculation result
    console.log('[computeCalculatedLogoutTime] Calculation result:', {
        paidBreakMinutesTaken,
        unpaidBreakMinutesTaken,
        excessPaidBreak: result.breakdown.excessPaidBreakMinutes,
        totalExtension: result.breakdown.totalExtensionMinutes,
        requiredLogoutTime: result.requiredLogoutTime.toISOString(),
        requiredLogoutTimeIST: result.requiredLogoutTime.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })
    });
    
    let requiredLogoutTime = result.requiredLogoutTime;
    
    // ============================================
    // PRESERVE EXISTING RULE: Early logout restriction
    // For 10 AM - 7 PM shift, ensure logout never goes below 7:00 PM
    // ============================================
    const isSpecialShift = userShift.shiftType === 'Fixed' && 
                          userShift.startTime && 
                          (userShift.startTime === '10:00' || 
                           userShift.startTime === '10:00 AM' ||
                           (typeof userShift.startTime === 'string' && userShift.startTime.startsWith('10:00'))) &&
                          userShift.endTime && 
                          (userShift.endTime === '19:00' || 
                           userShift.endTime === '7:00 PM' ||
                           userShift.endTime === '19:00:00' ||
                           (typeof userShift.endTime === 'string' && (userShift.endTime.startsWith('19:') || userShift.endTime.startsWith('7:'))));
    
    if (isSpecialShift) {
        const sevenPM = setTime(clockInTime, '19:00');
        // Enforce minimum logout time: never before 7:00 PM
        if (requiredLogoutTime < sevenPM) {
            requiredLogoutTime = sevenPM;
        }
    }
    
    // Return both the time and breakdown for API responses
    return {
        requiredLogoutTime: requiredLogoutTime.toISOString(),
        breakdown: {
            ...result.breakdown,
            requiredLogoutTime: requiredLogoutTime.toISOString()
        }
    };
};

const getUserDailyStatus = async (userId, targetDate, options = {}) => {
    const resolvedOptions = { ...DEFAULT_OPTIONS, ...options };
    const response = buildBaseResponse(resolvedOptions);

    // PHASE 2 OPTIMIZATION: Parallelize independent queries
    // Batch 1: User + AttendanceLog (independent, can run in parallel)
    const [user, attendanceLog] = await Promise.all([
        User.findById(userId).populate('shiftGroup').lean(),
        AttendanceLog.findOne({ user: userId, attendanceDate: targetDate }).lean()
    ]);

    if (!user) {
        return response;
    }

    response.shift = user.shiftGroup || null;

    if (!attendanceLog) {
        // HARD RULE: When no attendance log exists, explicitly set all flags to false/null
        // This prevents ANY late/half-day logic from executing without a log
        // CRITICAL: Do NOT compute lateness based on shift start time alone
        response.hasLog = false;
        response.attendanceLog = null; // Must be null, not undefined
        response.sessions = resolvedOptions.includeSessions ? [] : undefined;
        response.breaks = resolvedOptions.includeBreaks ? [] : undefined;
        response.status = 'Not Clocked In';
        response.calculatedLogoutTime = null;
        // Ensure no late/half-day flags leak through
        // (already null from buildBaseResponse, but being explicit)
        return response;
    }

    // ONLY reach here if attendance log exists
    // Log exists - set hasLog to true and map attendance data
    response.hasLog = true;
    response.attendanceLog = mapAttendanceLog(attendanceLog);

    // CRITICAL: Recalculate late/half-day status from CURRENT clockInTime
    // This ensures admin edits to clockInTime immediately affect the response
    if (attendanceLog.clockInTime && response.shift && response.shift.startTime) {
        const recalculatedStatus = await recalculateLateStatus(
            attendanceLog.clockInTime,
            response.shift
        );
        // Override stored values with recalculated values
        response.attendanceLog.isLate = recalculatedStatus.isLate;
        response.attendanceLog.isHalfDay = recalculatedStatus.isHalfDay;
        response.attendanceLog.lateMinutes = recalculatedStatus.lateMinutes;
        response.attendanceLog.attendanceStatus = recalculatedStatus.attendanceStatus;
    } else {
        // Fallback if shift or clockInTime is missing
        response.attendanceLog.isLate = false;
        response.attendanceLog.isHalfDay = false;
        response.attendanceLog.lateMinutes = 0;
        response.attendanceLog.attendanceStatus = 'On-time';
    }

    // PHASE 2 OPTIMIZATION: Parallelize independent queries
    // Batch 2: Sessions + Breaks + AutoBreak (independent if attendanceLog exists)
    let sessions = [];
    let breaks = [];
    let autoBreakDoc = null;

    if (resolvedOptions.includeSessions || resolvedOptions.includeBreaks || resolvedOptions.includeAutoBreak) {
        const batch2Promises = [];
        
        if (resolvedOptions.includeSessions) {
            batch2Promises.push(
                AttendanceSession.find({ attendanceLog: attendanceLog._id }).sort({ startTime: 1 }).lean()
            );
        } else {
            batch2Promises.push(Promise.resolve([]));
        }

        if (resolvedOptions.includeBreaks) {
            batch2Promises.push(
                BreakLog.find({ attendanceLog: attendanceLog._id }).sort({ startTime: 1 }).lean()
            );
        } else {
            batch2Promises.push(Promise.resolve([]));
        }

        if (resolvedOptions.includeAutoBreak) {
            batch2Promises.push(
                BreakLog.findOne({
                    userId,
                    endTime: null,
                    isAutoBreak: true,
                }).sort({ startTime: 1 }).lean()
            );
        } else {
            batch2Promises.push(Promise.resolve(null));
        }

        const [sessionsResult, breaksResult, autoBreakResult] = await Promise.all(batch2Promises);
        
        sessions = sessionsResult;
        breaks = breaksResult;
        autoBreakDoc = autoBreakResult;

        if (resolvedOptions.includeSessions) {
            response.sessions = sessions;
        }

        if (resolvedOptions.includeBreaks) {
            response.breaks = breaks;
            const activeBreakDoc = breaks.find(b => !b.endTime);
            response.activeBreak = mapActiveBreak(activeBreakDoc);
        }

        if (resolvedOptions.includeAutoBreak) {
            response.autoBreak = mapAutoBreak(autoBreakDoc);
        }
    }

    // PHASE 2 OPTIMIZATION: Parallelize independent queries
    // Batch 3: ExtraBreakRequests (independent, can run in parallel)
    if (resolvedOptions.includeRequests) {
        const [pendingRequest, approvedRequest] = await Promise.all([
            ExtraBreakRequest.findOne({
                user: userId,
                attendanceDate: targetDate,
                status: 'Pending',
            }).lean(),
            ExtraBreakRequest.findOne({
                user: userId,
                attendanceDate: targetDate,
                status: 'Approved',
                isUsed: false,
            }).lean()
        ]);
        response.pendingExtraBreakRequest = pendingRequest;
        response.approvedExtraBreak = approvedRequest;
    }

    const hasActiveSession = sessions.some(s => !s.endTime);
    const hasManualSessions = sessions.length > 0;
    const autoBreakActive = !!response.autoBreak;
    const hasAnyActiveBreak = !!response.activeBreak || autoBreakActive;

    if (hasAnyActiveBreak) {
        response.status = autoBreakActive ? 'On Auto-Break' : 'On Break';
    } else if (hasActiveSession) {
        response.status = 'Clocked In';
    } else if (hasManualSessions) {
        response.status = 'Clocked Out';
    } else {
        response.status = 'Not Clocked In';
    }

    // Pass activeBreak to the calculation function
    const logoutCalculation = computeCalculatedLogoutTime(sessions, breaks, response.attendanceLog, response.shift, response.activeBreak);
    
    if (logoutCalculation) {
        response.calculatedLogoutTime = logoutCalculation.requiredLogoutTime;
        response.logoutBreakdown = logoutCalculation.breakdown;
    } else {
        response.calculatedLogoutTime = null;
        response.logoutBreakdown = null;
    }

    return response;
};

module.exports = {
    getUserDailyStatus,
    computeCalculatedLogoutTime, // Export for testing
    recalculateLateStatus, // Export for use in admin routes
};

